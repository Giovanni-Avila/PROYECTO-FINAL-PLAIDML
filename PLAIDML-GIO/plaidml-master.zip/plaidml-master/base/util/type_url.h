// Copyright 2019, Intel Corp.

#pragma once

namespace vertexai {

constexpr char kTypeVertexAI[] = "type.vertex.ai";
constexpr char kTypeVertexAIPrefix[] = "type.vertex.ai/";

}  // namespace vertexai
