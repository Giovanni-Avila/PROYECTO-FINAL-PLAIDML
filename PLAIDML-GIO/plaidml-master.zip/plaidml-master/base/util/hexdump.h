#pragma once

#include <stddef.h>

namespace vertexai {

void hexdump(int log_level, void* buf, size_t len);

}  // namespace vertexai
