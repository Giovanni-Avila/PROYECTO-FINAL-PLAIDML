// Copyright 2018 Intel Corporation.

#pragma once

#include "base/context/context.h"

struct vai_ctx {
  vertexai::context::Activity activity;
};
