.. plaidml documentation master file, created by
   sphinx-quickstart on Thu Dec 19 14:39:59 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to plaidml's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   usage/install
   usage/building
   manual_api/index

