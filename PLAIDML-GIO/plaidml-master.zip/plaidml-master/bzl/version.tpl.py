# Provides access to the version of a package

{PREFIX}_VERSION = "{VERSION}"
