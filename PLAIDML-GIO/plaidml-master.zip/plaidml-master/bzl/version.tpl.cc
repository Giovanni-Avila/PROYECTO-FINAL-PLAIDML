// Provides access to the version of a package
const char* {PREFIX}_VERSION = "{VERSION}";
